function openMenu(){
    document.getElementById('sidebar').classList.toggle('active');
}